void main() {
    Scanner scanner = new Scanner(System.in);

    IO.print("Digite um número de 1 à 7:");
    int DIA = scanner.nextInt();

    switch (DIA) {
        case 1:
            IO.print("Domingo");
            break;
        case 2:
            IO.print("Segunda");
            break;
        case 3:
            IO.print("terça");
            break;
        case 4:
            IO.print("Quarta");
            break;
        case 5:
            IO.print("Quinta");
            break;
        case 6:
            IO.print("Sexta");
            break;
        case 7:
            IO.print("Sábado");
            break;
        default:
            IO.print("nùmero inválido");
    }
}
