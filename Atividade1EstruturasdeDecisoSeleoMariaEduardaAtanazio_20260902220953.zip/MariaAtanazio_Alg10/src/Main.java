//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
    Scanner scanner = new Scanner(System.in);

    System.out.print("Digite o salário atual: R$ ");
    double salario = scanner.nextDouble();


    if (salario < 1000.00) {
        double NovoSalario = salario * 1.30;
          System.out.println("Novo salário:R$"+NovoSalario);
    }
    else {
        System.out.println("O funcionário não tem direito ao aumento.");
    }

}
