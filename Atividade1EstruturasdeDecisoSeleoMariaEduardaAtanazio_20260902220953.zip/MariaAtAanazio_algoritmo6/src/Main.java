import java.util.Scanner;

void main() {
    Scanner scanner = new Scanner(System.in);

    System.out.print("Digite sua idade :");
    int Idade = scanner.nextInt();
    if (Idade >= 18) {
        System.out.println("Você é maior de idade.");
    }
    else {
        System.out.println("Você nâo é maior de idade.");
    }
    }


