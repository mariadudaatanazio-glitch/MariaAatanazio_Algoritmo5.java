//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
    Scanner scanner = new Scanner(System.in);

    System.out.println("Digite um número:");
    double Numero1 = scanner.nextDouble();
     System.out.println("Digite o segundo número:");
    double Numero2 = scanner.nextDouble();

    int Opcao = scanner.nextInt();
    switch (Opcao) {
        case 1:
            System.out.println("Resultado da Soma: " + (Numero1 + Numero2));
            break;
        case 2:
            System.out.println("Resultado da Subtração: " + (Numero1 -Numero2));
            break;
        case 3:
            System.out.println("Resultado da Multiplicação: " + (Numero1* Numero2));
            break;
        case 4:
            if (Numero1!= 0) {
                System.out.println("Resultado da Divisão: " + (Numero1 / Numero2));
            } else {
                System.out.println("Erro: Não é possível dividir por zero!");
            }
            break;
        case 5:
            System.out.println("Programa encerrado.");
            break;
        default:
            System.out.println("Opção inválida! Escolha um número entre 1 e 5.");
            break;
    }

}
