//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
    Scanner scanner = new Scanner(System.in);
    System.out.println("Digite sua idade:");
    int Idade= scanner.nextInt();
    if(Idade<=7) {
        System.out.println("INFANTIL");
    } else if (Idade<=10) {
        System.out.println("JUVENIL");
    } else if (Idade<=15) {
        System.out.println("ADOLECENTE");
    } else if (Idade<=30) {
        System.out.println("ADULTO");
    }
    else {
        System.out.println("SENIOR");
    }

}




