void main() {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Digite seu salário:");

    double Salario=scanner.nextInt();

    if(Salario>=1621) {
        System.out.println("Você recebe pelo menos 1 salário ");
    }
    else{
        System.out.println("Você não recebe um salário");
    }
}
