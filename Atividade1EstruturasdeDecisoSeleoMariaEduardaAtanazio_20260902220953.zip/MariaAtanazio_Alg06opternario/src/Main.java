import  java.util.Scanner;

void main() {

    Scanner scanner = new Scanner(System.in);

    System.out.print("Digite sua idade :");
    int Idade = scanner.nextInt();
    System.out.println(18<=Idade? "Maior de idade": "Menor de idade");

}
