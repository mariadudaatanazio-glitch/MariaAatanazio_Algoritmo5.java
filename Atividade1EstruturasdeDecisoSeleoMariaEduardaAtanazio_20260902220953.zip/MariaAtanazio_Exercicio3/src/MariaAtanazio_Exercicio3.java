void main() {
    Scanner scanner = new Scanner(System.in);
    {
        System.out.print("Digite o número da sua conta");
        int numero_da_cont = scanner.nextInt();
        System.out.print("Digite o seu saldo:");
        double saldo = scanner.nextDouble();
        System.out.print("Digite o seu débito");
        double debito = scanner.nextDouble();
        System.out.print("Digite o seu crédito");
        double credito = scanner.nextDouble();
        double Saldo_atual;

        Saldo_atual = saldo - debito + credito;
        System.out.print("O saldo atual é:" + Saldo_atual);

        if (Saldo_atual <= 0){
            System.out.println(numero_da_cont+"Seu saldo é Positivo.");
        }
        else {
            System.out.println(numero_da_cont+"Seu saldo é negativo");
        }

    }
}