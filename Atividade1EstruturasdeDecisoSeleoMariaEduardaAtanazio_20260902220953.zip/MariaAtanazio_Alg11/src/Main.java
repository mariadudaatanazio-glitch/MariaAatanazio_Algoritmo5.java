import java.util.Scanner;

   class MariaAtanazio_Alg11{
    static void main() {
        Scanner scanner = new Scanner(System.in);


        System.out.print("Digite o lado X: ");
        int ladoX = scanner.nextInt();

        System.out.print("Digite o lado Y: ");
        int ladoY = scanner.nextInt();
        System.out.print("Digite o lado Z: ");
        int ladoZ = scanner.nextInt();

        boolean E_Triangulo = (ladoX < ladoY + ladoZ) && (ladoY < ladoX + ladoZ) && (ladoZ < ladoX + ladoY);

        if (E_Triangulo) {
            if (ladoX == ladoY && ladoX == ladoZ) {
                System.out.println("Os lados formam um Triângulo Equilátero.");
            } else if (ladoX == ladoY || ladoX == ladoZ || ladoY == ladoZ) {
                System.out.println("Os lados formam um Triângulo Isósceles.");
            } else {
                System.out.println("Os lados formam um Triângulo Escaleno.");
            }
        } else {
            System.out.println("Esses valores não formarm um triângulo.");
        }
    }
    }