void main() {
    Scanner scanner = new Scanner(System.in);
//Dados
    IO.print("Digite o número de maçãs:");

    int NUMERO_DE_MACAS = scanner.nextInt();
    float NUMERO_MENOR_QUE_12 = 1.30f;
    float NUMERO_MAIOR_QUE_12 = 1.0f;
    //Condições
    if (NUMERO_DE_MACAS>12) {
        IO.println("O valor da é maçãs:R$" + NUMERO_MAIOR_QUE_12);

    } else {
        IO.println("O valor da é maçãs:R$" + NUMERO_MENOR_QUE_12);

    }
}

