void main() {
    Scanner scanner = new Scanner(System.in);

    System.out.print("Digite o valor da dureza:");
    double Dureza = scanner.nextDouble();

    System.out.print("Digite o valor do teor do carvão:");
    double Teor_De_Carvao = scanner.nextDouble();

    System.out.print("Digite o valor da resistência da tração:");
    System.out.println();

    int PontuacaoDoAco =0;
    if (Dureza <= 50) {
        PontuacaoDoAco++;
        if (Teor_De_Carvao >= 0.7) {
            PontuacaoDoAco++;
            if (Resistencia_Da_Tracao <= 5600) {
                PontuacaoDoAco++;

                switch (PontuacaoDoAco) {
                    case 3:
                        System.out.print("Pontuação igual a 10");
                        break;
                    case 2:
                        System.out.print("Pontuação igual a 8");
                        break;
                    case 1:
                        System.out.print("Pontuação igual a 7");
                        break;
                        default:
                            System.out.println("Pontuação igual a 5");
                }
            }
        }
    }
}