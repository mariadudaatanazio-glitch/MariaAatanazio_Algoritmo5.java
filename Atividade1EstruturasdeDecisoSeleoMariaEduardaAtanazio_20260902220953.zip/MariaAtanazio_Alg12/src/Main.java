//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
    Scanner scanner = new Scanner(System.in);

    System.out.println("CARDÁPIO");
    System.out.println("1 - Feijoada ");
    System.out.println("2 - Macarrão");
    System.out.println("3 -  à Parmegiana");
    System.out.println("4 - Salada completa");

    System.out.print("Digite o número do prato que você deseja: ");
    int Opcao = scanner.nextInt();

    switch (Opcao){
        case 1:
            System.out.println(" Feijoada ");
            break;
        case 2:
            System.out.println("Macarrão");
        break;
        case 3:
            System.out.println(" à Parmegiana");
            break;
        case  4:
            System.out.println(" Salada completa");
            break;
        default:
            System.out.println("Digite apenas os números do cardápio");
            break;
    }
}